// making db ready !
mongoimport--db persons--collection persons--file persons.json--jsonArray

// Compound Queries
// Imlicit and 
db.persons.find({ "dob.age": { $gt: 30 }, "nat": "CA" }).pretty()
// $or operator
db.persons.find({ $or: [{ "dob.age": { $gt: 30 } }, { "nat": "CA" }] }).pretty()

db.persons.aggregate([
    { $match: { gender: 'male' } },
    { $group: { _id: { state: "$location.state" }, personCount: { $sum: 1 } } },
    { $sort: { personCount: -1 } }
]).pretty()

// project
db.persons.aggregate([
    {
        $project: {
            _id: 0,
            gender: 1,
            email: 1,
            age: "$dob.age",

            location: {
                coordinates: [
                    {
                        $convert: {
                            input: '$location.coordinates.longitude',
                            to: 'double',
                            onError: 0.0,
                            onNull: 0.0
                        }
                    },
                    {
                        $convert: {
                            input: '$location.coordinates.latitude',
                            to: 'double',
                            onError: 0.0,
                            onNull: 0.0
                        }
                    }
                ]
            }
            ,
            fullName: {
                $concat: [
                    { $toUpper: { $substrCP: ["$name.first", 0, 1] } },
                    {
                        $substrCP: [
                            '$name.first', 1, {
                                $subtract: [{ $strLenCP: '$name.first' }, 1]
                            }
                        ]
                    },
                    " ",
                    { $toUpper: { $substrCP: ["$name.last", 0, 1] } },
                    {
                        $substrCP: [
                            '$name.last', 1, {
                                $subtract: [{ $strLenCP: '$name.last' }, 1]
                            }
                        ]
                    }
                ]
            }
        }
    }, {
        $out: "transformedPersons"
    }
]).pretty()


/*  To find People with age > 50 by gender, find avg age & number of persons corresponding to that group sort:ascending */

// db.persons.aggregate([
//     {$match:{"dob.age":{$gt: 50}}},
//     {$group:{_id:{gender:"$gender"},averageAge:{$avg: "$dob.age"}, personCount:{$sum:1}}},
//     {$sort:{personCount:1}}
// ]).pretty()
//

// With AG pipeline
// Can make use of Indexes
db.persons.aggregate([
    { $match: { gender: 'male' } },
    { $group: { _id: { state: "$location.state" }, personCount: { $sum: 1 } } },
    { $sort: { personCount: -1 } }
]).pretty()
// 
// Map -> properties
// Reduce
// used for very large datasets
// X : can't use Indexes !
// X : functions -> always may not be secure
db.persons.mapReduce(
    function () { emit(this.location.state, 1) },
    function (key, values) { return Array.sum(values) }, {
    query: { gender: 'male' },
    out: 'persons_male_stategroup'
}
)

// Creating Index
db.persons.createIndex({ "dob.age": 1 })

// Analysing by explain()
db.persons.explain().find({ "dob.age": { $gt: 30 } })

// compound
db.persons.createIndex({ "dob.age": 1, gender: 1 })

db.products.insertMany([
    { title: 'DSLR', description: "That camera is professional !" },
    { title: 'Hero Go Pro 8', description: " Thats an action camera !" }
])

// creating text
db.products.createIndex({ description: "text" })
// find / serach "need"
db.products.explain().find({ $text: { $search: "need" } })

// Search for term "Camera Laptop"
db.products.find({ $text: { $search: "\"Camera Laptop\"" } })

db.products.find({ $text: { $search: "need Camera" } }, { score: { $meta: 'textScore' } })

db.places.insertOne({
    name: 'Wankhede Stadium',
    location: {
        type: "Point", coordinates: [72.8235753, 18.9388528]
    }
})

// the geo query
db.places.find({
    location: {
      $near: {
        $geometry: {
          type: "Point",
          coordinates:[72.8236752, 18.9358065],
        },
        $minDistance: 10,
        $maxDistance: 350,
      },
    },
  })

// create a geospatial index
db.places.createIndex({ location: "2dsphere" });


db.places.insertMany([
    {
    name: "Fashion Street",
    location: {
        type: "Point", coordinates: [72.83008910376144,18.939294565271076]
    }
    },
    {
        name: "Metro INOX Cinema",
        location: {
            type: "Point", coordinates: [72.82995254798305,18.43241167809738]
        }
        },
        {
            name: "Marine Lines Station West",
            location: {
                type: "Point", coordinates: [ 72.82435376106918,18.944920239507923]
            }
            }
])

//18.941849104109696, 72.8273124696009




db.places.find({
    location: {
      $geoWithin: {
        $geometry: {
          type: "Polygon",
          coordinates:[[p1,p2,p3,p4,p1]]
        }
      },
    },
  })

  db.places.insertOne({
    name: 'Academy',
    location: {
        type: "Point", coordinates: [72.82572558136752,  18.942066987653263]
    }
})


db.getSiblingDB("db1").foo.insert(
    { abc: 0 },
    { writeConcern: { w: "majority", wtimeout: 2000 } }
  );
  db.getSiblingDB("db2").bar.insert(
    { xyz: 0 },
    { writeConcern: { w: "majority", wtimeout: 2000 } }
  );
  session = db.getMongo().startSession({ readPreference: { mode: "primary" } });
  
  coll1 = session.getDatabase("db1").foo;
  coll2 = session.getDatabase("db2").bar;
  session.startTransaction();
  try {
    coll1.insertOne({ abc: 1 });
    coll2.insertOne({ xyz: 999 });
  } catch (error) {
    // Abort transaction on error
    session.abortTransaction();
    throw error;
  }
  session.commitTransaction();
  
  session.endSession();
  

